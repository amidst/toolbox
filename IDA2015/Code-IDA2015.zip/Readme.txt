This is the code for the paper

"Modeling concept drift: A probabilistic graphical models approach"

==================

Install Java 8 and IntelliJ

http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html

http://www.jetbrains.com/idea/download/

In IntelliJ open maven project and point to the pom file. Also you need to point to the Java 8 installation and you ready to rock.

===========

The jar file "moalink.jar" is a MOA plugin that integrates within MOA the models described in this paper. It appears
as a new classfier in the Bayesian classifiers folder.

